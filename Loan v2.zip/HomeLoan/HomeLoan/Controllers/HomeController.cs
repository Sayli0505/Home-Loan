﻿using HomeLoan.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Security.Claims;
using HomeLoan.Interfaces;
using HomeLoan.Repository;
using static System.Net.Mime.MediaTypeNames;
using Microsoft.AspNetCore.Authorization;
using System.Diagnostics;
using System.Security.Principal;


namespace HomeLoan.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HomeController : ControllerBase
    {
        [Authorize(Roles ="customer")]
        [HttpPost("ChangePassword")]
        public IActionResult ChangePassword([FromBody] ChangePassword changePasswordModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var user = _userRepository.GetUserByEmail(changePasswordModel.Email);

                if (user == null)
                {
                    return BadRequest("User not found");
                }

                if (user.Password != changePasswordModel.CurrentPassword)
                {
                    return BadRequest("Current password is incorrect");
                }

                user.Password = changePasswordModel.NewPassword;

                _userRepository.UpdateUser(user);

                return Ok("Password changed successfully.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred while changing the password: {ex.Message}");
            }
        }
        [HttpGet("EligibilityCalculator")]
        public IActionResult EligibilityCalculator(double montlyIncome, double interestRate)
        {
            if (interestRate == 0)
            {
                interestRate = 8.2;
            }

            double decimalInterestRate = interestRate / 100;

            int Amount = (int)(60 * (0.6 * montlyIncome) / (int)(1 + decimalInterestRate));

            return Ok(new { LoanAmount = Amount });
        }

        [HttpGet("EMICalculator")]
        public IActionResult EMICalculator(double loanAmount, int loanTenure, double interestRate)
        {
            if (interestRate == 0)
            {
                interestRate = 8.2;
            }
            double decimalInterestRate = interestRate / 100;
            int n = loanTenure * 12;


            double monthlyInterestRate = decimalInterestRate / 12;


            int emi = (int)(loanAmount * monthlyInterestRate * Math.Pow((1 + monthlyInterestRate), n) / (Math.Pow((1 + monthlyInterestRate), n - 1)));

            return Ok(new { YearlyEMI = emi * 12 });
        }

        private readonly IPersonalDetails _personalDetailsRepository;
        private readonly ILoanDetails _loanDetailsRepository;
        private readonly IUser _userRepository;
        private readonly IUploadDocuments _uploadDocumentsRepository;
        private readonly ILoanTracker _loanTrackerRepository;
 
        public HomeController( IUser userRepository,IPersonalDetails personalDetailsRepository, ILoanDetails loanDetailsRepository, IUploadDocuments uploadDocumentsRepository, ILoanTracker loanTrackerRepository)
        {
            _userRepository = userRepository;
            _personalDetailsRepository = personalDetailsRepository;
            _loanDetailsRepository = loanDetailsRepository;
            _uploadDocumentsRepository = uploadDocumentsRepository;
            _loanTrackerRepository = loanTrackerRepository;
        }

        [Authorize(Roles = "customer")]
        [HttpPost("AddPersonalDetails")]
        public IActionResult AddPersonalDetails([FromBody] Personal_Details personalDetails)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                int age = CalculateAge(personalDetails.DOB);
                if (age < 18) // Assuming minimum age requirement is 18
                {
                    ModelState.AddModelError("DOB", "Applicant must be at least 18 years old.");
                    return BadRequest(ModelState);
                }

                var user = _userRepository.GetUserByEmail(personalDetails.Email);

                if (user == null)
                {
                    return BadRequest("User not found");
                }

                personalDetails.User = user;

                _personalDetailsRepository.AddPersonalDetails(personalDetails);

                return Ok("Personal details added successfully.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred while adding personal details: {ex.Message}");
            }
        }
        private int CalculateAge(DateTime dateOfBirth)
        {
            var today = DateTime.Today;
            var age = today.Year - dateOfBirth.Year;
            if (dateOfBirth.Date > today.AddYears(-age))
                age--;
            return age;
        }

        [Authorize(Roles = "customer")]
        [HttpPost("AddLoanDetails")]
        public async Task<IActionResult> AddLoanDetails([FromBody] Loan_Details loanDetails)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var personalDetails = _personalDetailsRepository.GetPersonalDetailsByApplicationId(loanDetails.Application_Id);

                if (personalDetails == null)
                {
                    return BadRequest("Personal details not found for the given Application Id");
                }

                loanDetails.Personal_Details = personalDetails;

                _loanDetailsRepository.AddLoanDetails(loanDetails);
                await _loanDetailsRepository.UpdateStatusToPending(loanDetails.Application_Id);

                return Ok("Loan details added successfully.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred while adding loan details: {ex.Message}");
            }
        }
        
        [Authorize(Roles = "customer")]
        [HttpPost("UploadDocuments")]
        public IActionResult UploadDocuments([FromForm] UploadDocuments model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {

                model.Loan_Details = _loanDetailsRepository.GetLoanDetailsByLoanId(model.Loan_Id);

                // Save uploaded files and update file paths in the model
                model.PanCardPath = SaveFile(model.PanCardFile);
                model.VoterIdPath = SaveFile(model.VoterIdFile);
                model.SalarySlipPath = SaveFile(model.SalarySlipFile);
                model.LOAPath = SaveFile(model.LOAFile);
                model.NOC_from_BuilderPath = SaveFile(model.NOC_from_BuilderFile);
                model.Agreement_To_SalePath = SaveFile(model.Agreement_To_SaleFile);

                // Add the model to the database
                _uploadDocumentsRepository.AddUploadDocument(model);

               // _loanTrackerRepository.UpdateStatusToPending(model.Loan_Id);

                return Ok($"Files uploaded successfully!");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        private string SaveFile(IFormFile file)
        {
            if (file == null || file.Length == 0)
                return null;

            var fileName = Guid.NewGuid().ToString() + Path.GetExtension(file.FileName);
            var filePath = Path.Combine("uploads", fileName); // Assuming uploads folder exists

            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                file.CopyToAsync(stream);
            }

            return filePath;
        }
        [Authorize(Roles = "customer")]
        [HttpGet("{loanId}")] // Change the parameter name from applicationId to loanId
        public async Task<IActionResult> GetLoanTracker(int loanId) // Change the parameter name from applicationId to loanId
        {
            try
            {
                var tracker = await _loanTrackerRepository.GetLoanTrackerByLoanId(loanId); // Call the updated method
                if (tracker == null)
                {
                    return NotFound("Loan tracker not found.");
                }

                return Ok(tracker);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

    }
}
