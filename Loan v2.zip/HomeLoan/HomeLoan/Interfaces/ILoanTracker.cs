﻿using HomeLoan.Models;

namespace HomeLoan.Interfaces
{
    public interface ILoanTracker
    {
        Task<LoanTracker> GetLoanTrackerByLoanId(int loanId);
  
    }
}
