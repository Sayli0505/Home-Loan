﻿using HomeLoan.Models;

namespace HomeLoan.Interfaces
{
    public interface IAdmin
    {
        Task UpdateLoanTracker(LoanTracker tracker);
        Task<IEnumerable<LoanTracker>> GetPendingLoanApplications();
    }
}
