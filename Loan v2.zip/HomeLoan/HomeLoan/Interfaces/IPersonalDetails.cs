﻿using HomeLoan.Models;

namespace HomeLoan.Interfaces
{
    public interface IPersonalDetails
    {
        void AddPersonalDetails(Personal_Details personalDetails);
        bool ApplicationExists(double applicationId);
        Personal_Details GetPersonalDetailsByApplicationId(int applicationId);
    }
}
