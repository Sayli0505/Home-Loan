﻿using HomeLoan.Models;

namespace HomeLoan.Interfaces
{
    public interface ILoanDetails
    {
        void AddLoanDetails(Loan_Details loanDetails);
        Loan_Details GetLoanDetailsByLoanId(int loanId);
        Task UpdateStatusToPending(int loanId);

    }
}
