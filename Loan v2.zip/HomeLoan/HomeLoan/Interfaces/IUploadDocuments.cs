﻿using HomeLoan.Models;

namespace HomeLoan.Interfaces
{
    public interface IUploadDocuments
    {
        void AddUploadDocument(UploadDocuments uploadDocuments);
        
    }
}
