﻿using HomeLoan.Models;
using HomeLoan.Interfaces;
using Microsoft.EntityFrameworkCore;
namespace HomeLoan.Repository
{
    public class LoanTrackerRepository : ILoanTracker
    {
        private readonly LoanDBContext _context;

        public LoanTrackerRepository(LoanDBContext context)
        {
            _context = context;
        }

        public async Task<LoanTracker> GetLoanTrackerByLoanId(int loanId) // Change the parameter name from applicationId to loanId
        {
            return await _context.LoanTrackers.FirstOrDefaultAsync(t => t.Loan_Id == loanId);
        }

    }
}
