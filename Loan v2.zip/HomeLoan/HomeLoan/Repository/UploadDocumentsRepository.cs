﻿using HomeLoan.Models;
using HomeLoan.Interfaces;
using Microsoft.EntityFrameworkCore;
namespace HomeLoan.Repository
{
    public class UploadDocumentsRepository : IUploadDocuments
    {
        private readonly LoanDBContext _context;

        public UploadDocumentsRepository(LoanDBContext context)
        {
            _context = context;
        }

        public void AddUploadDocument(UploadDocuments uploadDocuments)
        {
            _context.UploadDocuments.Add(uploadDocuments);
            _context.SaveChangesAsync();
        }
        

    }
}
