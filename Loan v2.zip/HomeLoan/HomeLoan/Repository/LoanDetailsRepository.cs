﻿using HomeLoan.Models;
using HomeLoan.Interfaces;
using Microsoft.EntityFrameworkCore;
namespace HomeLoan.Repository
{
    public class LoanDetailsRepository : ILoanDetails
    {
        private readonly LoanDBContext _context;

        public LoanDetailsRepository(LoanDBContext context)
        {
            _context = context;
        }

        public void AddLoanDetails(Loan_Details loanDetails)
        {
            _context.LoanDetails.Add(loanDetails);
            _context.SaveChanges();
        }
        public Loan_Details GetLoanDetailsByLoanId(int loanId)
        {
            return _context.LoanDetails.FirstOrDefault(ld => ld.Loan_Id == loanId);
        }
        public async Task UpdateStatusToPending(int applicationId)
        {
            var loanDetail = await _context.LoanDetails.FirstOrDefaultAsync(ld => ld.Application_Id == applicationId);
            if (loanDetail != null)
            {
                var tracker = await _context.LoanTrackers.FirstOrDefaultAsync(t => t.Loan_Id == applicationId);
                if (tracker != null)
                {
                    tracker.Status = "Pending";
                    tracker.Remark = "Pending";
                }
                else
                {
                    // Create a new LoanTracker if not found
                    tracker = new LoanTracker
                    {
                        Loan_Id = applicationId,
                        Status = "Pending",
                        Remark = "Pending"
                    };
                    _context.LoanTrackers.Add(tracker);
                }

                await _context.SaveChangesAsync();
            }
            else
            {
                throw new ArgumentException($"Loan details with application ID {applicationId} not found.");
            }
        }
      
    }
}
