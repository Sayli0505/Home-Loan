﻿using HomeLoan.Interfaces;
using HomeLoan.Models;
using Microsoft.EntityFrameworkCore;

namespace HomeLoan.Repository
{
    public class PersonalDetailsRepository : IPersonalDetails
    {
        private readonly LoanDBContext _context;

        public PersonalDetailsRepository(LoanDBContext context)
        {
            _context = context;
        }

        public void AddPersonalDetails(Personal_Details personalDetails)
        {
            _context.PersonalDetails.Add(personalDetails);
            _context.SaveChanges();
        }
        
        public bool ApplicationExists(double applicationId)
        {
            return _context.PersonalDetails.Any(p => p.Application_Id == applicationId);
        }
        public Personal_Details GetPersonalDetailsByApplicationId(int applicationId)
        {
            return _context.PersonalDetails.FirstOrDefault(pd => pd.Application_Id == applicationId);
        }
        
    }
}
