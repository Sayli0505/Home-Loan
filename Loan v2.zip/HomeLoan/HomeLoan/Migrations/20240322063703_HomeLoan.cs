﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace HomeLoan.Migrations
{
    public partial class HomeLoan : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    Email = table.Column<string>(type: "varchar(60)", nullable: false),
                    UserName = table.Column<string>(type: "varchar(50)", nullable: false),
                    Password = table.Column<string>(type: "varchar(20)", nullable: false),
                    Role = table.Column<string>(type: "varchar(10)", nullable: false),
                    PhoneNo = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: false),
                    ResetPasswordOTP = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.Email);
                });

            migrationBuilder.CreateTable(
                name: "PersonalDetails",
                columns: table => new
                {
                    Application_Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    First_Name = table.Column<string>(type: "varchar(30)", nullable: false),
                    Middle_Name = table.Column<string>(type: "varchar(30)", nullable: false),
                    Last_Name = table.Column<string>(type: "varchar(30)", nullable: false),
                    PhoneNo = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: false),
                    DOB = table.Column<DateTime>(type: "Date", nullable: false),
                    Gender = table.Column<string>(type: "varchar(15)", nullable: false),
                    Nationality = table.Column<string>(type: "varchar(30)", nullable: false),
                    Addhar_No = table.Column<string>(type: "varchar(12)", maxLength: 12, nullable: false),
                    Pan_No = table.Column<string>(type: "varchar(20)", nullable: false),
                    Email = table.Column<string>(type: "varchar(60)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PersonalDetails", x => x.Application_Id);
                    table.ForeignKey(
                        name: "FK_PersonalDetails_Users_Email",
                        column: x => x.Email,
                        principalTable: "Users",
                        principalColumn: "Email",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "LoanDetails",
                columns: table => new
                {
                    Loan_Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Property_Location = table.Column<string>(type: "varchar(50)", nullable: false),
                    Property_Name = table.Column<string>(type: "varchar(50)", nullable: false),
                    Estimated_Amount = table.Column<int>(type: "int", nullable: false),
                    Type_Of_Emmployment = table.Column<string>(type: "varchar(30)", nullable: false),
                    Retirement_Age = table.Column<int>(type: "int", nullable: false),
                    Organization_Name = table.Column<string>(type: "varchar(50)", nullable: false),
                    Employeer_Name = table.Column<string>(type: "varchar(50)", nullable: false),
                    Net_salary = table.Column<int>(type: "int", nullable: false),
                    Max_Loan_Grantable = table.Column<int>(type: "int", nullable: false),
                    Interest_Rate = table.Column<double>(type: "float", nullable: false),
                    Tenure = table.Column<int>(type: "int", nullable: false),
                    Loan_Amount = table.Column<int>(type: "int", nullable: false),
                    Application_Id = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LoanDetails", x => x.Loan_Id);
                    table.ForeignKey(
                        name: "FK_LoanDetails_PersonalDetails_Application_Id",
                        column: x => x.Application_Id,
                        principalTable: "PersonalDetails",
                        principalColumn: "Application_Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "LoanTrackers",
                columns: table => new
                {
                    Traker_Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Status = table.Column<string>(type: "varchar(20)", nullable: false),
                    Remark = table.Column<string>(type: "varchar(100)", nullable: false),
                    Loan_Id = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LoanTrackers", x => x.Traker_Id);
                    table.ForeignKey(
                        name: "FK_LoanTrackers_LoanDetails_Loan_Id",
                        column: x => x.Loan_Id,
                        principalTable: "LoanDetails",
                        principalColumn: "Loan_Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "UploadDocuments",
                columns: table => new
                {
                    Document_Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PanCardPath = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    VoterIdPath = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SalarySlipPath = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    LOAPath = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    NOC_from_BuilderPath = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Agreement_To_SalePath = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Loan_Id = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UploadDocuments", x => x.Document_Id);
                    table.ForeignKey(
                        name: "FK_UploadDocuments_LoanDetails_Loan_Id",
                        column: x => x.Loan_Id,
                        principalTable: "LoanDetails",
                        principalColumn: "Loan_Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Accounts",
                columns: table => new
                {
                    Account_Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Account_no = table.Column<double>(type: "float", nullable: false),
                    Balance = table.Column<int>(type: "int", nullable: false),
                    Tracker_Id = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Accounts", x => x.Account_Id);
                    table.ForeignKey(
                        name: "FK_Accounts_LoanTrackers_Tracker_Id",
                        column: x => x.Tracker_Id,
                        principalTable: "LoanTrackers",
                        principalColumn: "Traker_Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Accounts_Tracker_Id",
                table: "Accounts",
                column: "Tracker_Id");

            migrationBuilder.CreateIndex(
                name: "IX_LoanDetails_Application_Id",
                table: "LoanDetails",
                column: "Application_Id");

            migrationBuilder.CreateIndex(
                name: "IX_LoanTrackers_Loan_Id",
                table: "LoanTrackers",
                column: "Loan_Id");

            migrationBuilder.CreateIndex(
                name: "IX_PersonalDetails_Email",
                table: "PersonalDetails",
                column: "Email");

            migrationBuilder.CreateIndex(
                name: "IX_UploadDocuments_Loan_Id",
                table: "UploadDocuments",
                column: "Loan_Id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Accounts");

            migrationBuilder.DropTable(
                name: "UploadDocuments");

            migrationBuilder.DropTable(
                name: "LoanTrackers");

            migrationBuilder.DropTable(
                name: "LoanDetails");

            migrationBuilder.DropTable(
                name: "PersonalDetails");

            migrationBuilder.DropTable(
                name: "Users");
        }
    }
}
