﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HomeLoan.Models
{
    public class User
    {
        [Key]
        [Required(ErrorMessage = "This field is required")]
        [Column("Email", TypeName = "varchar(60)")]
        public string Email { get; set; }
        [Required(ErrorMessage = "UserName is required")]
        [Column("UserName", TypeName = "varchar(50)")]
        public string UserName { get; set; }
        [Required(ErrorMessage = "Password is required")]
        [Column("Password", TypeName = "varchar(20)")]
        public string Password { get; set; }
        [Required(ErrorMessage = "This field is required")]
        [Column("Role", TypeName = "varchar(10)")]
        public string Role { get; set; }
        [Required(ErrorMessage = "Phone number is required")]
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Phone number must be 10 digits")]
        public string PhoneNo { get; set; }

        public string ResetPasswordOTP { get; set; } = string.Empty;
    }
}
