﻿namespace HomeLoan.Models
{
    public class ForgotPassword
    {
        public string Email { get; set; }
    }
}
