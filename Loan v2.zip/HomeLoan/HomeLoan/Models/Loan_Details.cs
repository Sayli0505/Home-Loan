﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HomeLoan.Models
{
    public class Loan_Details
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Loan_Id { get; set; }
        [Column("Property_Location", TypeName = "varchar(50)")]
        [Required]
        public string Property_Location { get; set; }
        [Column("Property_Name", TypeName = "varchar(50)")]
        [Required]
        public string Property_Name { get; set; }
        [Required]
        public int Estimated_Amount { get; set; }
        [Column("Type_Of_Emmployment", TypeName = "varchar(30)")]
        [Required]
        public string Type_Of_Employment { get; set; }
        [Required]
        public int Retirement_Age { get; set; }
        [Column("Organization_Name", TypeName = "varchar(50)")]
        [Required]
        public string Organization_Name { get; set; }
        [Column("Employeer_Name", TypeName = "varchar(50)")]
        [Required]
        public string Employeer_Name { get; set; }
        [Required]
        public int Net_salary { get; set; }
        public int Max_Loan_Grantable { get; set; }
        public double Interest_Rate { get; set; }
        [Required]
        public int Tenure {  get; set; }
        [Required]
        public int Loan_Amount {  get; set; }
        [ForeignKey("Personal_Details")]
        [Required]
        public int Application_Id { get; set; }
        public virtual Personal_Details Personal_Details { get; set; }
    }
}
