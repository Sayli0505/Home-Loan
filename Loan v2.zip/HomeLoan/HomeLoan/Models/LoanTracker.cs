﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HomeLoan.Models
{
    public class LoanTracker
    {

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Traker_Id { get; set; }
        [Column("Status", TypeName = "varchar(20)")]

        public string Status { get; set; }
        [Column("Remark", TypeName = "varchar(100)")]

        public string Remark { get; set; }
        [ForeignKey("Loan_Details")]
        public int Loan_Id { get; set; }
        public virtual Loan_Details Loan_Details { get; set; }
    }
}
