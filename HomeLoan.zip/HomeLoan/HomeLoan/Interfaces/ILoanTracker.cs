﻿using HomeLoan.Models;

namespace HomeLoan.Interfaces
{
    public interface ILoanTracker
    {
        Task<LoanTracker> GetLoanTrackerByApplicationId(int applicationId);
  
    }
}
