﻿using HomeLoan.Models;

namespace HomeLoan.Interfaces
{
    public interface IUser
    {
        bool AddUser(User user);
        User GetUserByEmail(string email);
        User GetUserByEmailAndPassword(string email, string password);
        void UpdateUser(User user);
    }
}
