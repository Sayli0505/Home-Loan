﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace HomeLoan.Models
{
    public class Personal_Details
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Application_Id { get; set; }

        [Required]
        [Column("First_Name", TypeName = "varchar(30)")]
        public string First_Name { get; set; }
        [Column("Middle_Name", TypeName = "varchar(30)")]

        public string Middle_Name { get; set; }
        [Column("Last_Name", TypeName = "varchar(30)")]
        [Required]
        public string Last_Name { get; set; }
        [Required]
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Phone number must be 10 digits")]
        public double PhoneNo { get; set; }
        [Required(ErrorMessage = "Date of Birth is required")]
        [Column(TypeName = "date")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [DOBValidation(ErrorMessage = "Age must be above 18 years")]
        public DateTime DOB {  get; set; }
        [Column("Gender", TypeName = "varchar(15)")]
        [Required]
        public string Gender { get; set; }
        [Column("Nationality", TypeName = "varchar(30)")]
        [Required]
        public string Nationality { get; set; }
        [Required]
        [Column("Addhar_No", TypeName = "varchar(20)")]
        [StringLength(12, MinimumLength = 12, ErrorMessage = "Addhar number must be 12 digits")]
        public string Addhar_No { get; set; }
       
        [Column("Pan_No", TypeName = "varchar(20)")]
        [Required]
        public string Pan_No { get; set; }
        [Required]
        [ForeignKey("User")]
        public string Email { get; set; }
        public virtual User User { get; set; }

        public class DOBValidationAttribute : ValidationAttribute
        {
            protected override ValidationResult IsValid(object value, ValidationContext validationContext)
            {
                if (value != null)
                {
                    DateTime dob = (DateTime)value;
                    int age = DateTime.Today.Year - dob.Year;
                    if (age < 18)
                    {
                        return new ValidationResult(ErrorMessage);
                    }
                }
                return ValidationResult.Success;
            }
        }
    }
}
