﻿using Microsoft.EntityFrameworkCore;

namespace HomeLoan.Models
{
    public class LoanDBContext : DbContext
    {
        public LoanDBContext(DbContextOptions options) : base(options)
        {

        }
        public DbSet<User> Users { get; set; }
        public DbSet<Loan_Details> LoanDetails { get; set; }
        public DbSet<Personal_Details> PersonalDetails { get; set; }
        public DbSet<UploadDocuments> UploadDocuments { get; set; }
        public DbSet<LoanTracker> LoanTrackers { get; set; }
        public DbSet<Account> Accounts { get; set; }
    }
}
