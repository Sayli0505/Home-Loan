﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HomeLoan.Models
{
    public class LoanTracker
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Traker_Id { get; set; }
        [Column("Status", TypeName = "varchar(20)")]

        public string Status { get; set; }
        [Column("Remark", TypeName = "varchar(100)")]

        public string Remark { get; set; }
        [ForeignKey("Personal_Details")]
        public int Application_Id { get; set; }
        public virtual Personal_Details Personal_Details { get; set; }
    }
}
