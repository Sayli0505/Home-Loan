﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HomeLoan.Models
{
    public class UploadDocuments
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Document_Id { get; set; }

        [Required(ErrorMessage = "PanCard file is required")]
        [NotMapped] // This property is not mapped to the database
        public IFormFile PanCardFile { get; set; }

        public string PanCardPath { get; set; }

        [Required(ErrorMessage = "VoterId file is required")]
        [NotMapped] // This property is not mapped to the database
        public IFormFile VoterIdFile { get; set; }

        public string VoterIdPath { get; set; }

        [Required(ErrorMessage = "SalarySlip file is required")]
        [NotMapped] // This property is not mapped to the database
        public IFormFile SalarySlipFile { get; set; }

        public string SalarySlipPath { get; set; }

        [Required(ErrorMessage = "LOA file is required")]
        [NotMapped] // This property is not mapped to the database
        public IFormFile LOAFile { get; set; }

        public string LOAPath { get; set; }

        [Required(ErrorMessage = "NOC_from_Builder file is required")]
        [NotMapped] // This property is not mapped to the database
        public IFormFile NOC_from_BuilderFile { get; set; }

        public string NOC_from_BuilderPath { get; set; }

        [Required(ErrorMessage = "Agreement_To_Sale file is required")]
        [NotMapped] // This property is not mapped to the database
        public IFormFile Agreement_To_SaleFile { get; set; }

        public string Agreement_To_SalePath { get; set; }

        [ForeignKey("Loan_Details")]
        [Required(ErrorMessage = "Loan_Id is required")]
        public int Loan_Id { get; set; }

        public virtual Loan_Details Loan_Details { get; set; }
    }
}
