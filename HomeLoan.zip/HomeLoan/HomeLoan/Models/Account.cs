﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Numerics;

namespace HomeLoan.Models
{
    public class Account
    {

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Account_Id { get; set; }
        public double Account_no { get; set; }
        public int Balance { get; set; }
        [ForeignKey("LoanTracker")]
        public int Tracker_Id { get; set; }
        public virtual LoanTracker LoanTracker { get; set; }
    }
}
