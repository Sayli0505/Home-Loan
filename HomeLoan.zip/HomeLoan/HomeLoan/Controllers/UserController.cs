﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using HomeLoan.Models;
using System.Numerics;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using HomeLoan.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Runtime.Intrinsics.X86;
using Microsoft.AspNetCore.Identity;
using HomeLoan.Helper;
using HomeLoan.Service;
using HomeLoan.Repository;


namespace HomeLoan.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUser _userRepository;
        private readonly IConfiguration _configuration;
        private readonly LoanDBContext _context;
        private readonly IEmailService _emailService;


        public UserController(IConfiguration configuration, LoanDBContext context, IUser userRepository, IEmailService emailService)
        {
            _context = context;
            _configuration = configuration;
            _userRepository = userRepository;
            _emailService = emailService;
        }

        [HttpPost("Register")]
        public async Task<IActionResult> Register([FromBody] User userModel)
        {

            if (_userRepository.GetUserByEmail(userModel.Email) != null)
            {
                return Conflict("User with this email already exists.");
            }

            userModel.Password = GenerateRandomPassword(8);
            User newUser = new User
            {
                Email = userModel.Email,
                UserName = userModel.UserName,
                Password = userModel.Password,
                Role = "customer",
                PhoneNo = userModel.PhoneNo
            };
            bool created = _userRepository.AddUser(newUser);

            if (created)
            {
                //return Ok("Signup successful");
                var mailRequest = new Mailrequest
                {
                    ToEmail = userModel.Email,
                    Subject = "Confirmation Email",
                    Body = $"Thank you for signing up.Your username is: {userModel.UserName} and your password is: {userModel.Password}"
                };
                await _emailService.SendEmailAsync(mailRequest);
                return Ok("Signup Successfully");
            }
            else
            {
                return BadRequest("Failed to create user.");
            }
            
        }
       
        private string GenerateRandomPassword(int length)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            Random random = new Random();
            return new string(Enumerable.Repeat(chars, length)
              .Select(s => s[random.Next(s.Length)]).ToArray());
        }

        [HttpPost("Login")]
        public IActionResult Login([FromBody] Login model)
        {


            if (model != null && model.Email != null && model.Password != null)
            {
                var user = _userRepository.GetUserByEmailAndPassword(model.Email, model.Password);
                var jwt = _configuration.GetSection("Jwt").Get<Jwt>();
                if (model != null)
                {
                    var claims = new[]
                    {
                 new Claim(JwtRegisteredClaimNames.Sub,jwt.Subject),
                 new Claim(JwtRegisteredClaimNames.Jti,Guid.NewGuid().ToString()),
                 new Claim(JwtRegisteredClaimNames.Iat,DateTime.UtcNow.ToString()),
                 new Claim(ClaimTypes.Role, user.Role),
                 new Claim("Email",model.Email),
                 new Claim("Password",model.Password),

             };
                    var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwt.key));

                    var signin = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
                    var token = new JwtSecurityToken(
                        jwt.Issuer,
                        jwt.Audience,
                        claims,
                        expires: DateTime.Now.AddMinutes(20),
                        signingCredentials: signin
                        );
                    return Ok(new JwtSecurityTokenHandler().WriteToken(token));


                }

                else
                {
                    return BadRequest("Invalid");
                }
            }
            else
            {
                return BadRequest("Invalid");
            }

        }
    }
}    

