﻿using HomeLoan.Interfaces;
using HomeLoan.Models;
using HomeLoan.Repository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace HomeLoan.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        private readonly IUser _userRepository;
        private readonly IConfiguration _configuration;
        private readonly LoanDBContext _context;
        private readonly ILoanTracker _loanTrackerRepository;
        private readonly IAdmin _adminRepository;
        public AdminController(IConfiguration configuration, LoanDBContext context, IUser userRepository, ILoanTracker loanTrackerRepository,IAdmin adminRepository)
        {
            _context = context;
            _configuration = configuration;
            _userRepository = userRepository;
            _loanTrackerRepository = loanTrackerRepository;
            _adminRepository = adminRepository;
        }

        [HttpPost("Login")]
        public IActionResult Login([FromBody] Login model)
        {


            if (model != null && model.Email != null && model.Password != null)
            {
                var user = _userRepository.GetUserByEmailAndPassword(model.Email, model.Password);
                var jwt = _configuration.GetSection("Jwt").Get<Jwt>();
                if (model != null)
                {
                    var claims = new[]
                    {
                 new Claim(JwtRegisteredClaimNames.Sub,jwt.Subject),
                 new Claim(JwtRegisteredClaimNames.Jti,Guid.NewGuid().ToString()),
                 new Claim(JwtRegisteredClaimNames.Iat,DateTime.UtcNow.ToString()),
                 new Claim(ClaimTypes.Role, user.Role),
                 new Claim("Email",model.Email),
                 new Claim("Password",model.Password),

             };
                    var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwt.key));

                    var signin = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
                    var token = new JwtSecurityToken(
                        jwt.Issuer,
                        jwt.Audience,
                        claims,
                        expires: DateTime.Now.AddMinutes(20),
                        signingCredentials: signin
                        );
                    return Ok(new JwtSecurityTokenHandler().WriteToken(token));


                }

                else
                {
                    return BadRequest("Invalid");
                }
            }
            else
            {
                return BadRequest("Invalid");
            }
        }


        // GET: api/admin/applications/pending
        [HttpGet("applications/pending")]
        public async Task<IActionResult> GetPendingApplications()
        {
            var pendingApplications = await _adminRepository.GetPendingLoanApplications();
            return Ok(pendingApplications);
        }

        [Authorize(Roles = "Admin")]
        // POST: api/admin/applications/approve/{id}
        [HttpPost("applications/approve/{id}")]
        public async Task<IActionResult> ApproveApplication(int id)
        {
            var tracker = await _loanTrackerRepository.GetLoanTrackerByApplicationId(id);
            if (tracker == null)
            {
                return NotFound($"Loan tracker with ID {id} not found.");
            }

            tracker.Status = "Approved";
            tracker.Remark = "Approved";
            await _adminRepository.UpdateLoanTracker(tracker);
            var account = new Account
            {
                Account_no = GenerateAccountNumber(12), // Generate a unique account number
                //Balance = tracker.Loan_Details.Loan_amount, // Set initial balance to the loan amount
                LoanTracker = tracker
            };
            _context.Accounts.Add(account);
            await _context.SaveChangesAsync();
            return Ok($"Loan application with ID {id} approved successfully. Account created with account number: {account.Account_no}");
        }
        private double GenerateAccountNumber(int length)
        {
            const string chars = "0123456789";
            Random random = new Random();

            string accountNumberString = new string(Enumerable.Repeat(chars, length)
                .Select(s => s[random.Next(s.Length)]).ToArray());
            if (double.TryParse(accountNumberString, out double accountNumber))
            {
                return accountNumber;
            }
            else
            {
                // Handle parsing failure if needed
                throw new InvalidOperationException("Failed to parse the generated account number.");
            }
        }
        [Authorize(Roles = "Admin")]
        [HttpPost("ChangePassword")]
        public IActionResult ChangePassword([FromBody] ChangePassword changePasswordModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var user = _userRepository.GetUserByEmail(changePasswordModel.Email);

                if (user == null)
                {
                    return BadRequest("User not found");
                }

                if (user.Password != changePasswordModel.CurrentPassword)
                {
                    return BadRequest("Current password is incorrect");
                }

                user.Password = changePasswordModel.NewPassword;

                _userRepository.UpdateUser(user);

                return Ok("Password changed successfully.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred while changing the password: {ex.Message}");
            }
        }

        [Authorize(Roles = "Admin")]
        // POST: api/admin/applications/reject/{id}
        [HttpPost("applications/reject/{id}")]
        public async Task<IActionResult> RejectApplication(int id)
        {
            var tracker = await _loanTrackerRepository.GetLoanTrackerByApplicationId(id);
            if (tracker == null)
            {
                return NotFound($"Loan tracker with ID {id} not found.");
            }

            tracker.Status = "Rejected";
            tracker.Remark = string.Empty;
            await _adminRepository.UpdateLoanTracker(tracker);

            return Ok($"Loan application with ID {id} rejected successfully.");
        }
    }
}
