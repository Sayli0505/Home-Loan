﻿using HomeLoan.Models;
using HomeLoan.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;

namespace HomeLoan.Repository
{
    public class AdminRepository : IAdmin
    {
        private readonly LoanDBContext _context;

        public AdminRepository(LoanDBContext context)
        {
            _context = context;
        }
        
        public async Task<IEnumerable<LoanTracker>> GetPendingLoanApplications()
        {
            var pendingApplications = await _context.LoanTrackers
           .Include(tracker => tracker.Personal_Details)
           //.Where(loanDetail => loanDetail.Application_Id === applicationid)
           .Where(tracker => tracker.Status == "Pending")
           .ToListAsync();

            var pendingApplicationsViewModel = pendingApplications.Select(tracker => new LoanTracker
            {
                Personal_Details = tracker.Personal_Details,
                Traker_Id = tracker.Traker_Id, // Assuming you have a property named LoanTrackerId in LoanTracker entity
                Status = tracker.Status,
                Remark = tracker.Remark,
                // Add other properties you need from the LoanTracker entity
            });

            return pendingApplicationsViewModel;
        }
        public async Task UpdateLoanTracker(LoanTracker tracker)
        {
            _context.Entry(tracker).State = EntityState.Modified;
            _context.Entry(tracker).Property("Remark").IsModified = true;
            await _context.SaveChangesAsync();
        }
    }
}
