﻿using HomeLoan.Models;
using HomeLoan.Interfaces;
using Microsoft.AspNetCore.Identity;

namespace HomeLoan.Repository
{
    public class UserRepository : IUser
    {
        private readonly LoanDBContext _context;

        public UserRepository(LoanDBContext context)
        {
            _context = context;
        }

        public User GetUserByEmail(string email)
        {
            return _context.Users.FirstOrDefault(u => u.Email == email);
        }
        public User GetUserByEmailAndPassword(string email, string password)
        {
            return _context.Users.FirstOrDefault(u => u.Email == email && u.Password == password);
        }

        public bool AddUser(User user)
        {
             _context.Users.Add(user);
             var created= _context.SaveChanges();
            return created > 0; 
        }
        public void UpdateUser(User user)
        {
            _context.Users.Update(user);
            _context.SaveChanges();
        }
        
    }
    
}
