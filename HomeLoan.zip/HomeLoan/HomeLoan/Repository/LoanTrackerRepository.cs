﻿using HomeLoan.Models;
using HomeLoan.Interfaces;
using Microsoft.EntityFrameworkCore;
namespace HomeLoan.Repository
{
    public class LoanTrackerRepository : ILoanTracker
    {
        private readonly LoanDBContext _context;

        public LoanTrackerRepository(LoanDBContext context)
        {
            _context = context;
        }

        public async Task<LoanTracker> GetLoanTrackerByApplicationId(int applicationId)
        {
            return await _context.LoanTrackers.FirstOrDefaultAsync(t => t.Application_Id == applicationId);
        }


        public async Task<LoanTracker> GetLoanTrackerById(int id)
        {
            return await _context.LoanTrackers.FindAsync(id);
        }

    }
}
