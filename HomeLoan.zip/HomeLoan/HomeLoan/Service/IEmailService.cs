﻿using HomeLoan.Helper;

namespace HomeLoan.Service
{
    public interface IEmailService
    {
        Task SendEmailAsync(Mailrequest mailrequest);
    }
}
